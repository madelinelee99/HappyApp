package hu.ait.android.happy;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class ScrollingActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_LOCATION_PERMISSION = 401;
    private MyLocationManager locationManager;
    private TextView tvData;

    private Location prevLocation = null;
    private int distance = 0;
    private Context context;
    private String coordinates;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
/*
        setContentView(R.layout.view_fragment);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
*/
        locationManager = new MyLocationManager(this);

        requestNeededPermission();
    }


    public void requestNeededPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                Toast.makeText(ScrollingActivity.this, "I need it for GPS", Toast.LENGTH_SHORT).show();
            }

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_CODE_LOCATION_PERMISSION);
        } else {
            locationManager.startLocationMonitoring();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_LOCATION_PERMISSION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(ScrollingActivity.this, "FINE_LOC perm granted", Toast.LENGTH_SHORT).show();
                    locationManager.startLocationMonitoring();
                } else {
                    Toast.makeText(ScrollingActivity.this, "FINE_LOC perm NOT granted", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }



    @Override
    protected void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onStop() {
        locationManager.stopLocationMonitoring();
        EventBus.getDefault().unregister(this);
        super.onStop();
    }

    @Subscribe
    public void onLocationReceived(Location location) {
        //TODO: calculate distance


        Intent intentShowDetails = new Intent(context,WeatherActivity.class);
        coordinates = "lat="+location.getLatitude() + "&lon="+location.getLongitude();
        intentShowDetails.putExtra(WeatherActivity.KEY_COORD,
                coordinates);
    }





}
