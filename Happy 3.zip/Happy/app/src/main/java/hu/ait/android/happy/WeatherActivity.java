package hu.ait.android.happy;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;

import hu.ait.android.happy.adapter.MyPagerAdapter;


public class WeatherActivity extends ActionBarActivity {

    public static final String KEY_COORD = "KEY_COORD";


    private String coordName = "lat=35&lon=139";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_fragment);

        MyPagerAdapter adapter = new MyPagerAdapter(
                getSupportFragmentManager());

        ViewPager pager = (ViewPager) findViewById(R.id.pager);

        pager.setAdapter(adapter);

        if (getIntent() != null && getIntent().hasExtra(KEY_COORD)) {
            coordName = getIntent().getStringExtra(KEY_COORD);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        new HttpGetTask().execute("http://api.openweathermap.org/data/2.5/weather?"+coordName+"&appid=7bbe78cd9652922152ef8f205bc9c7d6");
    }

}
