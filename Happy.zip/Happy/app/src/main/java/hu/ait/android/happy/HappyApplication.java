package hu.ait.android.happy;

import com.orm.SugarApp;

/**
 * Created by miadeng on 5/21/16.
 */
public class HappyApplication extends SugarApp {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}
