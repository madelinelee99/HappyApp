package hu.ait.android.happy.adapter;

/**
 * Created by miadeng on 5/21/16.
 */
public interface TodoTouchHelperAdapter {
    void onItemDismiss(int position);

    void onItemMove(int fromPosition, int toPosition);

}


