package hu.ait.android.happy;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;


public class WeatherActivity extends ActionBarActivity {


    private String cityName = "Budapest";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weather_activity);
    }

    @Override
    protected void onResume() {
        super.onResume();
        new HttpGetTask().execute("http://api.openweathermap.org/data/2.5/weather?q="+
                cityName
                +"&units=metric&appid=7bbe78cd9652922152ef8f205bc9c7d6");
    }

}
